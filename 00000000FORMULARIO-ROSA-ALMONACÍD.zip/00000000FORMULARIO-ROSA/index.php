<!DOCTYPE html>
<html lang="en">

<head>
    <!-- CABECERA  -->
    <!-- ******************************************************* -->
    <title> Formulario jose alberto - 3D</title>
    <?php
include('0ArchivosFijos/2cabecera/2cabecera.php');
   ?>
</head>
<!-- ******************************************************* -->
<!-- INICIO DEL CUERPO  -->

<body><br>
    <video src="videoo.mp4" loop autoplay></video>

    <div id="particles-js"></div>

    <div class="container"> <br><br>

        <input type="radio" id="chk1" name="al" style="display:none" ;>
        <input type="radio" id="chk2" name="al" style="display:none" ;>
        <div class="box">
            <div class="a">
                <label for="chk1">VIDEO TECNIFAJAS</label>
                <label for="chk2" id="sup">Registrate</label>
            </div>
            <div class="b">
                <form action="" class="frm">
                    <h6 class="titulo"> Formulario Jose Alberto 2020</h6>
                    <input type="text" placeholder="nombre completo ">
                    <input type="text" placeholder=" nombre de usuario">
                    <input type="text" placeholder=" correo  ">
                    <input type="text" placeholder=" clave ">
                    <input type="text" placeholder="confirmar clave ">
                    <input type="button" value="Registratee" id="btn">
                    <label for="chk1" id="btm">Iniciar Sesion Aquí</label>
                </form>
            </div>


            <!-- *******************************************************falta arreglar el video  no encaja ******************* -->

            <div class="c">

                <div class=container>
                    <form action="" class="frm">
                        <video clas="video2" src="corazon1.mp4" loop autoplay></video>


                        <h6 class="titulo"> VIDEO TECNIFAJAS </h6>


                        <label for="chk2" id="btm">Registrate Aquí</label>
                </div>
                </form>
            </div>


        </div>
        <!-- *******************************************************falta arreglar el video  no encaja ******************* -->




        <div class="d"></div>
        <div class="e"></div>
    </div>
    </div>





    <!-- ******************************************************* -->
    <!-- FIN DEL CUERPO  -->

    <!-- FOOTER  -->
    <!-- ******************************************************* -->
    <?php
include('0ArchivosFijos/3footer/3footer.php');
?>
    <!-- ******************************************************* -->
</body>

</html>