<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no" />
<meta http-equiv="x-ua-compatible" content="ie=edge" />
<title>Formulario JOSE ALBERTO </title>



<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap" rel="stylesheet">

<!-- MDB icon -->
<link rel="icon" href="IMAGEN-00/img003.jpg" />
<!-- Google Fonts Roboto -->
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap" />
<!-- inico del bootstrap 4 .4.1 y MDboostrap en grupo -->
<!-- Bootstrap core CSS versio 4.4.1 del 2020 -->
<link rel="stylesheet"
    href="0ArchivosFijos/0librerias/Bootstrap_version_4.4.1-JOSEALBERTO/css/bootstrap-4.4.1.min.css" />
<!-- Material Design Bootstrap -->
<link rel="stylesheet"
    href="0ArchivosFijos/0librerias/MDB-Bootstrap_version_4.15.0-JOSEALBERTO/css/mdb-v4.15.0.min.css" />
<!-- fn del bootstrap 4 .4.1 y su flex y su MDboostrap en grupo -->
<link rel="stylesheet" href="0ArchivosFijos/0librerias/css-fontawesome-5.12.1/all.css" />
<!-- ***************************************************************************************** -->
<link rel="stylesheet" href="CSS/estilos.css">


<style>

</style>