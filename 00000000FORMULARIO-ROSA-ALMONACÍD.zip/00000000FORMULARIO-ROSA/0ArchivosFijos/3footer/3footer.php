 <!-- FOOTER  -->
 <!-- ***************************************************************************************** -->
 <!-- Inicio de este grupo de 4  es lo mas importante  de los scripts  -->
 <!--  MDB jQuery -->
 <script type="text/javascript"
     src="0ArchivosFijos/0librerias/MDB-Bootstrap_version_4.15.0-JOSEALBERTO/js/jquery-v3.4.1.min.js"></script>
 <!--  MDB Popper version_v1.14.7 JavaScript -->
 <script type="text/javascript"
     src="0ArchivosFijos/0librerias/MDB-Bootstrap_version_4.15.0-JOSEALBERTO/js/popper-v1.14.7.min.js">
 </script>
 <!-- Bootstrap version_4.4.1 JavaScript -->
 <script type="text/javascript"
     src="0ArchivosFijos/0librerias/Bootstrap_version_4.4.1-JOSEALBERTO/js/bootstrap-4.4.1.min.js"></script>

 <!-- MDB Bootstrap core JavaScript -->
 <script type="text/javascript"
     src=" 0ArchivosFijos/0librerias/MDB-Bootstrap_version_4.15.0-JOSEALBERTO/js/mdb-v4.15.0.min.js">
 </script>
 <!-- fin de este grupo de 4  es lo mas importante  de los scripts  -->
 <!-- ***************************************************************************************** -->

 <script src="JS/particles.js"></script>7
 <script src="JS/particulas1.js"></script>